---
description: 3 command
---

# 🔏 Owner

| Command                      | Slash | Description                |
| ---------------------------- | ----- | -------------------------- |
| **!eval \<script>**          | NA    | evaluates something        |
| **!leaveserver \<serverId>** | NA    | leave a server             |
| **!listservers \[match]**    | NA    | lists all/matching servers |
